const mainBody = document.querySelector(".mainBody");

for (let i = 1; i <= 50; i++) {
  const element = document.createElement("div");
  element.classList.add("element");
  element.textContent = `Elem ${i}`;
  mainBody.append(element);
}
mainBody.addEventListener("click", (e) => {
  alert(`CLICKED ${e.target.textContent}`);
});
