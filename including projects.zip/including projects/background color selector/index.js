const textPara = document.querySelector(".text");
const body = document.getElementsByTagName("body");
const circles = document.querySelectorAll(".all-colors div");

circles.forEach((circle) => {
  console.log(circle);
  circle.addEventListener("click", (e) => {
    console.log(e.target.className);
    document.body.style.backgroundColor = e.target.className;

    textPara.classList.add("hide");
    circles.forEach((each) => {
      each.classList.add("hide");
    });
    document.querySelector(".show").classList.remove("hide");
  });
});
