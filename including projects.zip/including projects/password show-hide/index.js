let password = document.getElementById("input");
let icon = document.querySelector("#imageIcon");

icon.addEventListener("click", () => {
  if (password.type === "password") {
    password.type = "text";
    icon.src = "../Images/Eye View.png";
  } else {
    password.type = "password";
    icon.src = "../Images/eye blocked.png";
  }
});
