let passwordBox = document.querySelector(".password");
let copyPara = document.querySelector(".copy-area");

let upperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
let lowerCase = "abcdefghijklmnopqrstuvwxyz";
let numbers = "1234567890";
let symbols = '!@#$%^&*(){}|:"<>?,./;[]';
let allChars = upperCase + lowerCase + numbers + symbols;

const passwordGenerate = () => {
  let password = "";
  copyPara.innerHTML = "";
  password += upperCase[Math.floor(Math.random() * upperCase.length)];
  password += lowerCase[Math.floor(Math.random() * lowerCase.length)];
  password += numbers[Math.floor(Math.random() * numbers.length)];
  password += symbols[Math.floor(Math.random() * symbols.length)];

  while (password.length <= 12) {
    password += allChars[Math.floor(Math.random() * allChars.length)];
  }
  passwordBox.value = password;
  console.log(password);
};

document.querySelector(".generate").addEventListener("click", () => {
  passwordBox.value = "";
  passwordGenerate();
});
document.querySelector(".show").addEventListener("click", () => {
  if (passwordBox.type === "password") {
    passwordBox.type = "text";
    document.querySelector(".show").src = "../Images/Eye View.png";
  } else {
    passwordBox.type = "password";
    document.querySelector(".show").src = "../Images/eye blocked.png";
  }
});

document.querySelector(".copy").addEventListener("click", () => {
  passwordBox.select();
  document.execCommand("copy");
  if (passwordBox.value === "") {
    copyPara.textContent = "Man...Generate password first";
  } else {
    copyPara.textContent = "copied....";
  }
});
