let text = document.getElementById("textSec");
let btn = document.getElementById("btn");
let body = document.body;

let messages = [
  `I said don't click`,
  "You deaf or wot? Don't click",
  "man i am gonna kill you",
  `bro i think you've got a problem`,
  `do whatever you want`,
];
let colors = [`green`, `red`, `yellow`, `purple`, `brown`];
let messageIndex = 0;

const doNotClick = (e) => {
  if (messageIndex < messages.length) {
    text.textContent = messages[messageIndex];
    if (messageIndex < colors.length) {
      btn.style.backgroundColor = colors[messageIndex];
      text.style.color = colors[messageIndex];
    }
    messageIndex++;
  } else {
    text.textContent = `You're Doomed man`;

    btn.style.backgroundColor = "grey";
    text.style.color = "grey";
    btn.removeEventListener("click", doNotClick); // Disable further clicks
  }
};

btn.addEventListener("click", doNotClick);
body.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    if (messageIndex < messages.length) {
      text.textContent = messages[messageIndex];
      if (messageIndex < colors.length) {
        btn.style.backgroundColor = colors[messageIndex];
        text.style.color = colors[messageIndex];
      }
      messageIndex++;
    } else {
      text.textContent = `You're Doomed man`;

      btn.style.backgroundColor = "grey";
      text.style.color = "grey";
      btn.removeEventListener("click", doNotClick); // Disable further clicks
    }
  }
});
