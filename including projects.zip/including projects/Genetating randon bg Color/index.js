let intervalId;
const colorChanging = () => {
  const randomColor = "0123456789ABCDEF";
  let color = "#";

  for (let i = 0; i < 6; i++) {
    color += randomColor[Math.floor(Math.random() * 16)];
  }
  return color;
};
const startChangingColor = () => {
  let body = document.querySelector("body");
  let change = () => {
    body.style.backgroundColor = colorChanging();
  };
  if (!intervalId) {
    intervalId = setInterval(change, 1500);
  }
};
stopChangingColor = () => {
  clearInterval(intervalId);
  intervalId = null;
};

const hideEverything = () => {
  document.querySelector("#start").classList.add("none");
  document.querySelector("#stop").classList.add("none");
  document.querySelector("#text").classList.add("none");
  document.querySelector("#hide").classList.add("none");
};
document.querySelector("#start").addEventListener("click", startChangingColor);
document.querySelector("#stop").addEventListener("click", stopChangingColor);
document.querySelector("#stop").addEventListener("click", stopChangingColor);
document.querySelector("#hide").addEventListener("click", hideEverything);
